# Defaults for openstack-dashboard-cloudbase-theme initscript
# sourced by /etc/init.d/openstack-dashboard-cloudbase-theme
# installed at /etc/default/openstack-dashboard-cloudbase-theme by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
