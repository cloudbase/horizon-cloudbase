?package(openstack-dashboard-cloudbase-theme):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="openstack-dashboard-cloudbase-theme" command="/usr/bin/openstack-dashboard-cloudbase-theme"
